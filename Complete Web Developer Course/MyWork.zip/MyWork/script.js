testMe = ()=> {
    let myElm = document.getElementById('name')
    myElm.innerHTML = 'OK!'
    console.log('ok here');
}


